local ReportTypePunishTable = class({}, Assets.req("Scripts.ConfigTable.Base.ReportTypePunishTableBase"))

--------------------------------------------自动生成--------------------------------------------

return ReportTypePunishTable
